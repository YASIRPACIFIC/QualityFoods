import React from "react";
import { useRouter } from "next/router";
import useStyles from "../utils/styles";
import Layout from "../components/layout";


export default function Certificate() {
  const classes = useStyles();
  const router = useRouter();
 
  return(
  <Layout title="certificate">

<h1>hello</h1>
  </Layout>
  );
}

