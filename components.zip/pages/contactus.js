import React,{useRef} from "react";
import { useRouter } from "next/router";
import useStyles from "../utils/styles";
import Layout from "../components/layout";
import {
  Card,
  CardContent,
  Container,
  Grid,
  Typography,
} from "@material-ui/core";
import { MdEmail } from "react-icons/md";
import { emailjs } from "@emailjs/browser";

export default function Contactus() {
  const classes = useStyles();
  const router = useRouter();
  const form = useRef();

  const SendEmail=(e) =>{
    e.preventDefault();

    emailjs.sendForm('gmail','template_3xx8muz',e.target,'user_yyJBgIgJ2vhW0POy7mBFA')
      
      .then(
        (result) => {
          console.log(result.text);
        },
        (error) => {
          console.log(error.text);
        }
      );
      e.target.reset()
  }
  return (
    <Layout title="contactus">
      <div className={classes.cover2}>
        <div>
        <Container>
          <form  onSubmit={SendEmail}>
          <label>Name</label>
      <input type="text" name="user_name" />
      <label>Email</label>
      <input type="email" name="user_email" />
      <label>Message</label>
      <textarea name="message" />
      <input type="submit" value="Send" />

          </form>
        </Container>
        </div>
       
      </div>
    </Layout>
  );
}
