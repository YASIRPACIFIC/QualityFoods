// import react from "react"
// import Image from "next/image"
// import data from "../../utils/data"
// import { useRouter } from "next/router"
// import Layout from "../../components/layout"
// import NextLink from "next/link"
// import useStyles from "../../utils/styles"
// import { Typography,Link } from "@material-ui/core"

// export default function productScreen(){
//     const router = useRouter();
//     const classes = useStyles();
//     const {slug}= router.query;
//     const product = data.products.find((a) => a.slug === slug);
//     if (!product){
//         return <div>products not found</div>
//     }
//     return(
//         <Layout title="products">
//             <div>
//                 <NextLink href="/" passHref>
//                     <Link>
//                     <Typography>back to home</Typography>
//                     </Link>
//                 </NextLink>
//             </div>
//             <Typography>name:{product.name}</Typography>
//         </Layout>
//     )
// }