
const data2={
  matter:[
    {
      images:"/images/incorporation.jpg",
      slug:"Certification-of-incorporation",
      

    },
    {
      images:"/images/DGFT.jpg",
      slug:"DGFT",
    },
    {
      images:"/images/FIEO.jpg",
      slug:"FIEO",
    },
    {
      images:"/images/GST.jpg",
      slug:"GST",
    },
    {
      images:"/images/NAFED.jpg",
      slug:"NAFED",
    },
  ],
};
export default data2;