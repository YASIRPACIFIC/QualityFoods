import { ThemeContext } from "@emotion/react";
import { makeStyles } from "@material-ui/core";
import { fontSize, maxWidth, width } from "@mui/system";
import { urlObjectKeys } from "next/dist/shared/lib/utils";
import Image from "next/image";

const useStyles = makeStyles({


  navbar: {
    backgroundColor: "#ffffff",
  "& a":{
    color:"#000000",
    marginLeft:10,
  },
  
    
  },
  main: {
    minHeight: "80vh",
  },
  root: {
    flexGrow: 5,
  },
  brand: {
    fontWeight:"bold",
    fontSize:"1.5rem",
    
  },
  cover: {
    backgroundImage: 'url("images/cover1.jpg")',
    width: "100%",

    minHeight: 350,
  },
  footer: {
    textAlign: "center",
    backgroundColor: "#21201e",
    color: "#ffffff",
    marginTop:10,
  },
  nav: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "space-between",
    width: "100%",
   
    // flexGrow:1,
    // marginTop: "1.5rem",
    // marginBottom: "1.5rem",
  },
  content: {
    padding: 45,
    textAlign: "center",
    color: "#ffffff",
  },
  intro: {
    backgroundColor: "#ffffff",
  },
  text: {
    color: "#000000",
    minHeight: "50vh",
  },
  spacing: {
    margin: 12,
    display:"flex"
  },
  grid1: {
    backgroundImage: 'url("images/cover2.jpeg")',
    backgroundSize:"cover",
    color: "#ffffff",
  },
  whatsappfloat: {
    position: "fixed",
    width: "60px",
    height: "60px",
    right: "40px",
    backgroundColor: "#25d366",
    borderRadius: "50px",
    textAlign: "center",
    fontSize: "30px",
    boxShadow: "2px 2px 3px #999",
    
  },
  whatsappicon: {
    marginTop: "16px",
  },
  link:{
     textDecorationLine:"none"
  },
  grow:{
    flexGrow:1
  },
  toolbar:{
    justifyContent:'space-between'
  },
cover2:{
  backgroundImage:'url("images/contact.jpg")',
  backgroundSize:"cover",
  width:"100%",
  minHeight:1000
}

 
 
});
export default useStyles;
