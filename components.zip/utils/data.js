const data={
    products:[
        {
            name:'Tamarind',
            slug:'tamarind',
            image:'/images/tamarind.jpg',
        },
        {
            name:'Bay Leafs',
            slug:'bay-leafs',
            image:'/images/bayleafs.jpg'
        },
         {
            name:'Black Pepper',
            slug:'black-pepper',
            image:'/images/Blackpepper.jpg',
        },
        {
            name:'Cambodge',
            slug:'cambodge',
            image:'/images/cambodge.jpg',
        },
        {
            name:'Chana Dal',
            slug:'chana-dal',
            image:'/images/chanadaal.jpg',
        },
        {
            name:'Chilly Powder',
            slug:'chilly-powder',
            image:'/images/chillypowder.jpg',
        },
        {
            name:'Cumin Seed',
            slug:'cumin-seed',
            image:'/images/cumin.jpg',
        },
        {
            name:'Jaggery',
            slug:'jaggery',
            image:'/images/jaggery.jpeg',
        },
        {
            name:'Masoor Dal',
            slug:'masoor-dal',
            image:'/images/masoordal.jpg',
        },
        {
            name:'Peanut',
            slug:'peanut',
            image:'/images/peanut.jpg',
        },
        {
            name:'Poha',
            slug:'poha',
            image:'/images/poha.png',
        },
        {
            name:'Turmeric Powder',
            slug:'turmeric-powder',
            image:'/images/turmericpowder.jpg',
        },
        
        
    ]
};
export default  data;