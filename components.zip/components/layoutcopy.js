import React, { useState } from "react";
import Head from "next/head";
import {
  AppBar,
  Toolbar,
  Typography,
  CssBaseline,
  Container,
  Link,
} from "@material-ui/core";
import useStyles from "../utils/styles";
import NextLink from "next/link";

 export default function Layout({children}){
  const classes=useStyles();
  return(
    <div>
      <Head>
        <title>Quality foods</title>
      </Head>
      <CssBaseline/>
      <AppBar  position="static" className={classes.navbar}>
        <Toolbar>
          <NextLink href="/" passHref>
            <Link>
            <Typography className={classes.brand}>QUALITY FOODS</Typography>
            </Link>
          </NextLink>
          <div className={classes.grow}></div>
          <NextLink href="/aboutus" passHref>
            <Link>
            <Typography>About us</Typography></Link>
          </NextLink>
          <NextLink href="/products">
            <Link>
            <Typography>Products</Typography>
            </Link>
          </NextLink>
          <NextLink href="/certificate">
            <Link>
            <Typography>Certificate</Typography>
            </Link>
          </NextLink>
          <NextLink href="/contact us">
            <Link>
            <Typography>Contact us</Typography>
            </Link>
          </NextLink>
        </Toolbar>
      </AppBar>
      {children}
      <footer className={classes.footer}> 
        <Typography>All right reserved.quality foods</Typography>
      </footer>
    </div>
  )
 }